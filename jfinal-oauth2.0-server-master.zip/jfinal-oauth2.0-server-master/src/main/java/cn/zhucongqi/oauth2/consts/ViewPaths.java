/**
 *  ViewPath ，所以页面对应的目录
 */
package cn.zhucongqi.oauth2.consts;

/**
 * 
 * @author BruceZCQ [zcq@zhucongqi.cn]
 * @version
 */
public class ViewPaths {

	// auth 的 dir
	public static final String AUTH_VIEW_PATH = "auth";
	
}
