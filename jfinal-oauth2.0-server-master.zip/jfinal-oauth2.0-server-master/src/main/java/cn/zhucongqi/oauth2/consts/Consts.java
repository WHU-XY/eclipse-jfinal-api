/**
 * 所有系统中用到的常量
 */
package cn.zhucongqi.oauth2.consts;

/**
 * 
 * @author BruceZCQ [zcq@zhucongqi.cn]
 * @version
 */
public class Consts {

	/**
	 * CaptchaRender random key
	 */
	public static final String CAPTCHA_RDNDOM_KEY = "captcha";
	
}
