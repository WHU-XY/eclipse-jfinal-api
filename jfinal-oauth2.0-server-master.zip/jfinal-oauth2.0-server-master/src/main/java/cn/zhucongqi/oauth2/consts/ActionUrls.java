/**
 * 所有的ActionUrls
 */
package cn.zhucongqi.oauth2.consts;

/**
 * 
 * @author BruceZCQ [zcq@zhucongqi.cn]
 * @version
 */
public class ActionUrls {

}
