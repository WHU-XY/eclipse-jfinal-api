
public interface Hello {
	
	public String ask(String name);
}
