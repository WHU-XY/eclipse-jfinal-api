package com.jade.controller.admin;

import com.jfinal.core.Controller;

public class UserController extends Controller {

}
