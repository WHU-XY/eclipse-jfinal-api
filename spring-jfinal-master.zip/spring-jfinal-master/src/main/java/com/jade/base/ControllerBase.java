package com.jade.base;

import com.jfinal.core.Controller;

/**   
 * 访问控制基类
 * @author jiangyf   
 * @since 2016年10月9日 下午12:18:51 
 * @version V1.0
 */
public class ControllerBase extends Controller {

}
