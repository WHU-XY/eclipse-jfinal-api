http://nakupanda.github.io/bootstrap3-dialog/
https://github.com/nakupanda/bootstrap3-dialog