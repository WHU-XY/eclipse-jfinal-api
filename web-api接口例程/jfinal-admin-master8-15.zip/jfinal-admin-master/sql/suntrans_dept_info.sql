INSERT INTO `suntrans_dept_info` VALUES (1, '1', '市场部');
INSERT INTO `suntrans_dept_info` VALUES (2, '2', '研发部');
INSERT INTO `suntrans_dept_info` VALUES (3, '3', '工程部');
INSERT INTO `suntrans_dept_info` VALUES (4, '4', '生产部');
INSERT INTO `suntrans_dept_info` VALUES (5, '5', '财保部');
INSERT INTO `suntrans_dept_info` VALUES (6, '6', '行管部');
