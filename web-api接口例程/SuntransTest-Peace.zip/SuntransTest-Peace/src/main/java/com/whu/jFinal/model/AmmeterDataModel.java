package com.whu.jFinal.model;

public class AmmeterDataModel {

	private int update_time;
	private String data;
	public int getUpdate_time() {
		return update_time;
	}
	public void setUpdate_time(int update_time) {
		this.update_time = update_time;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public AmmeterDataModel() {
		
	}
}
