package com.whu.jFinal.tasks;

public class Task1 implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		 System.out.println("my task!!!"); 
	}

}
