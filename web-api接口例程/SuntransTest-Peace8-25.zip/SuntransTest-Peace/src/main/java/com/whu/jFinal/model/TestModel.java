package com.whu.jFinal.model;


public class TestModel {
	private String userId;
	private String loginName;
	private String nickName;
	private String password;
	private int sex;
	private String email;
	public TestModel() {
		
	}
/*	public String getuserId() {
		return userId;
	}
	public void setuserId(String userId) {
		this.userId=userId;
	}
	public String getloginName() {
		return loginName;
	}
	public void setloginName(String loginName) {
		this.loginName=loginName;
	}
	public String getnickName() {
		return nickName;
	}
	public void setnickName(String nickName) {
		this.nickName=nickName;
	}
	public String getpassword() {
		return password;
	}
	public void setpassword(String password) {
		this.password=password;
	}
	public int getsex() {
		return sex;
	}
	public void setsex(int sex) {
		this.sex=sex;
	}
	public String getemail() {
		return email;
	}
	public void setemail(String email) {
		this.email=email;
	}*/
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getSex() {
		return sex;
	}
	public void setSex(int sex) {
		this.sex = sex;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
}
