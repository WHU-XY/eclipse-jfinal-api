package com.jflyfox.api.service.impl;

import com.jflyfox.api.service.IApiLogic;

/**
 * v1.0.1
 * 
 * 2016年9月29日 上午11:19:00 flyfox 369191470@qq.com
 */
public class ApiV101Logic extends ApiV100Logic implements IApiLogic {

	

}
