package com.whu.jFinal.api;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jfinal.aop.Before;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;
import com.whu.jFinal.bean.Code;
import com.whu.jFinal.common.Require;
import com.whu.jFinal.interceptor.TokenInterceptor;
import com.whu.jFinal.model.RolesInfo;
import com.whu.jFinal.model.StudentInfo;
import com.whu.jFinal.model.Version;
import com.whu.jFinal.response.InquiryDBResponse;
import com.whu.jFinal.response.InquiryResponse;
import com.whu.jFinal.response.InquiryRoleResponse;
import com.whu.jFinal.response.InquiryRoomIdResponse;

@Before(TokenInterceptor.class)
public class InquiryAPIController extends BaseAPIController {

	public void Inquiry_UserInfo() {

		String student_id = getPara("student_id");
		// 校验参数, 确保不能为空
		if (!notNull(Require.me().put(student_id, "student_id can not be null"))) {
			return;
		}
		String sql = "SELECT * FROM admin_student_info WHERE student_id=?";
		StudentInfo nowStudent = StudentInfo.dao.findFirst(sql, student_id);
		InquiryResponse response = new InquiryResponse();
		if (nowStudent == null) {
			response.setCode(Code.FAIL).setMessage("student_id is error");
			renderJson(response);
			return;
		}
		Map<String, Object> studentInfo = new HashMap<String, Object>(nowStudent.getAttrs());
		studentInfo.remove("password");
		response.setInfo(studentInfo);
		response.setMessage("Inquiry_UserInfo Success");
		renderJson(response);
	}

	public void Inquiry_RolesInfo() {
		String sql = "SELECT * FROM admin_role_info";
		List<RolesInfo> nowRole = RolesInfo.dao.find(sql);
		InquiryRoleResponse response = new InquiryRoleResponse();
		if (nowRole == null) {
			response.setCode(Code.FAIL).setMessage("Inquiry_RolesInfo fail，please try again");
			renderJson(response);
			return;
		}
		response.setInfo(nowRole);
		response.setMessage("Inquiry_RolesInfo Success");
		renderJson(response);

	}

	public void Inquiry_Version() {

		String type = getPara("type");

		String sql = "SELECT * FROM admin_version_info WHERE type=?";
		Version nowVersion = Version.dao.findFirst(sql, type);
		InquiryResponse response = new InquiryResponse();
		if (nowVersion == null) {
			response.setCode(Code.FAIL).setMessage("type is error");
			renderJson(response);
			return;
		}
		Map<String, Object> VersionInfo = new HashMap<String, Object>(nowVersion.getAttrs());
		response.setInfo(VersionInfo);
		response.setMessage("Inquiry_Version Success");
		renderJson(response);

	}

	public void Inquiry_Building() {

		String sql = "SELECT room_id,area,building,floor,room_num FROM admin_room_info";
		List<Record> nowBuilding = Db.find(sql);
		InquiryDBResponse response = new InquiryDBResponse();
		if (nowBuilding == null) {
			response.setCode(Code.FAIL).setMessage("Inquiry_Building fail，please try again");
			renderJson(response);
			return;
		}
		response.setInfo(nowBuilding);
		response.setMessage("Inquiry_Building Success");
		renderJson(response);

	}

	public void Inquiry_Building_Detail() {

		String area = getPara("area");
		String building = getPara("building");
		String floor = getPara("floor");
		List<Record> nowBuilding;

		if (!notNull(Require.me().put(area, "area can not be null").put(building, "building can not be null").put(floor,
				"floor can not be null"))) {
			return;
		}
		if (floor.equals("0")) {
			String sql = "SELECT room_id,area,building,floor,room_num FROM admin_room_info where area=? and building=? ";
			nowBuilding = Db.find(sql, area, building);
		} else {
			String sql = "SELECT room_id,area,building,floor,room_num FROM admin_room_info where area=? and building=? and floor=?";
			nowBuilding = Db.find(sql, area, building, floor);
		}
		InquiryDBResponse response = new InquiryDBResponse();
		if (nowBuilding.isEmpty()) {
			response.setCode(Code.FAIL).setMessage("area、building or floor is error");
			renderJson(response);
			return;
		}
		response.setInfo(nowBuilding);
		response.setMessage("Inquiry_Building_Detail Success");
		renderJson(response);

	}

	public void Inquiry_Student() {

		String sql = "SELECT a.room_id,a.area,a.building,a.floor,a.room_num,b.student_name,b.academy,b.professional"
				+ " FROM admin_room_info as a,admin_student_info as b where a.room_id=b.room_id";
		List<Record> nowBuilding = Db.find(sql);
		InquiryDBResponse response = new InquiryDBResponse();
		if (nowBuilding == null) {
			response.setCode(Code.FAIL).setMessage("Inquiry_Student fail，please try again");
			renderJson(response);
			return;
		}
		response.setInfo(nowBuilding);
		response.setMessage("Inquiry_Student Success");
		renderJson(response);

	}

	public void Inquiry_Student_Detail() {

		String area = getPara("area");
		String building = getPara("building");
		String floor = getPara("floor");
		List<Record> nowStudent;

		if (!notNull(Require.me()
				.put(area, "area can not be null").
				put(building, "building can not be null").
				put(floor,"floor can not be null")))
		{
			return;
		}
		if (floor.equals("0")) {
			String sql = "SELECT a.room_id,a.area,a.building,a.floor,a.room_num,b.student_name,b.academy,b.professional"
					+ " FROM admin_room_info as a,admin_student_info as b where a.room_id=b.room_id and a.area=? and a.building=?";
			nowStudent = Db.find(sql, area, building);
		} else {
			String sql = "SELECT a.room_id,a.area,a.building,a.floor,a.room_num,b.student_name,b.academy,b.professional"
					+ " FROM admin_room_info as a,admin_student_info as b where a.room_id=b.room_id and a.area=? and a.building=? and a.floor=?";
			nowStudent = Db.find(sql, area, building, floor);
		}
		InquiryDBResponse response = new InquiryDBResponse();
		if (nowStudent.isEmpty()) {
			response.setCode(Code.FAIL).setMessage("area、building or floor is error");
			renderJson(response);
			return;
		}
		response.setInfo(nowStudent);
		response.setMessage("Inquiry_Student_Detail Success");
		renderJson(response);

	}
	
	public void Inquiry_RoomDetail_RoomId() {

		String room_id = getPara("room_id");
		List<Record> nowRoom;
		List<Record> nowRoom1;
		List<Record> nowRoom2;
		List<Record> nowRoom3;

		if (!notNull(Require.me()
				.put(room_id,"room_id can not be null")))
		{
			return;
		}
		
		String sql = "SELECT a.account_balance,a.subsidy,a.mon_elec_consumption,a.total_elec_consumption "
				+ "FROM admin_account_elec_info as a where a.room_id=?";
		nowRoom = Db.find(sql,room_id);
		
		String sql1 = "SELECT b.name,b.status FROM admin_device_channel as b,admin_device_info as a where b.dev_id=a.dev_id and a.room_id=?";
		nowRoom1 = Db.find(sql1,room_id);
		
		String sql2 = "SELECT a.power,a.electricity,a.U_value,a.I_value,a.power_rate FROM admin_elec_meter_data as a,admin_elec_meter_info as b where b.dev_id=a.dev_id and b.room_id=?";
		nowRoom2 = Db.find(sql2,room_id);
		
		String sql3 = "SELECT student_name FROM admin_student_info where room_id=?";
		nowRoom3 = Db.find(sql3,room_id);
		
		InquiryRoomIdResponse response = new InquiryRoomIdResponse();
		if (nowRoom.isEmpty()||nowRoom1.isEmpty()||nowRoom2.isEmpty()||nowRoom3.isEmpty()) {
			response.setCode(Code.FAIL).setMessage("room_id is error");
			renderJson(response);
			return;
		}
		
		response.setaccount(nowRoom);
		response.setdev_channel(nowRoom1);
		response.setmeter_info(nowRoom2);
		response.setroom_stu(nowRoom3);
		
		response.setMessage("Inquiry_RoomDetail_RoomId Success");
		renderJson(response);

	}

	public void Inquiry_Data_History() {

		String room_id = getPara("room_id");
		String type = getPara("type");
		List<Record> nowStudent=null;

		if (!notNull(Require.me()
				.put(room_id,"floor can not be null")
				.put(type,"floor can not be null")
				))
		{
			return;
		}
		if (type.equals("account_balance")) {
			String sql = "SELECT a.room_id,a.area,a.building,a.floor,a.room_num,b.student_name,b.academy,b.professional"
					+ " FROM admin_room_info as a,admin_student_info as b where a.room_id=b.room_id and a.area=? and a.building=?";
			nowStudent = Db.find(sql,room_id);
		} 
		else if(type.equals("U_value")){
			String sql = "SELECT a.room_id,a.area,a.building,a.floor,a.room_num,b.student_name,b.academy,b.professional"
					+ " FROM admin_room_info as a,admin_student_info as b where a.room_id=b.room_id and a.area=? and a.building=? and a.floor=?";
			nowStudent = Db.find(sql,room_id);
		}else if(type.equals("I_value")){
			String sql = "SELECT a.room_id,a.area,a.building,a.floor,a.room_num,b.student_name,b.academy,b.professional"
					+ " FROM admin_room_info as a,admin_student_info as b where a.room_id=b.room_id and a.area=? and a.building=? and a.floor=?";
			nowStudent = Db.find(sql,room_id);
		}else if(type.equals("power")) {
			String sql = "SELECT a.room_id,a.area,a.building,a.floor,a.room_num,b.student_name,b.academy,b.professional"
					+ " FROM admin_room_info as a,admin_student_info as b where a.room_id=b.room_id and a.area=? and a.building=? and a.floor=?";
			nowStudent = Db.find(sql,room_id);
		}else if(type.equals("power_rate")) {
			String sql = "SELECT a.room_id,a.area,a.building,a.floor,a.room_num,b.student_name,b.academy,b.professional"
					+ " FROM admin_room_info as a,admin_student_info as b where a.room_id=b.room_id and a.area=? and a.building=? and a.floor=?";
			nowStudent = Db.find(sql,room_id);
		}else if(type.equals("power_rate")) {
			String sql = "SELECT a.room_id,a.area,a.building,a.floor,a.room_num,b.student_name,b.academy,b.professional"
					+ " FROM admin_room_info as a,admin_student_info as b where a.room_id=b.room_id and a.area=? and a.building=? and a.floor=?";
			nowStudent = Db.find(sql,room_id);
		}
		/*
		 * switch(type) { case "account_balance": String sql =
		 * "SELECT a.room_id,a.area,a.building,a.floor,a.room_num,b.student_name,b.academy,b.professional"
		 * +
		 * " FROM admin_room_info as a,admin_student_info as b where a.room_id=b.room_id and a.area=? and a.building=?"
		 * ; nowStudent = Db.find(sql,room_id);break; }
		 */
		InquiryDBResponse response = new InquiryDBResponse();
		if (nowStudent.isEmpty()) {
			response.setCode(Code.FAIL).setMessage("area、building or floor is error");
			renderJson(response);
			return;
		}
		response.setInfo(nowStudent);
		response.setMessage("Inquiry_Student_Detail Success");
		renderJson(response);

	}
}
